
const firebaseConfig = {
  apiKey: "AIzaSyBEinjKGGNZUG_f2JIak4SWrvpwCpow2h8",
  authDomain: "pulgas-barber-shop.firebaseapp.com",
  projectId: "pulgas-barber-shop",
  storageBucket: "pulgas-barber-shop.appspot.com",
  messagingSenderId: "292161699491",
  appId: "1:292161699491:web:7454dd2c882f8926d2c916",
  measurementId: "G-4LF17GBRMG"
};

firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.firestore();

function registrar() {
  const email = document.getElementById("email").value;
  const senha = document.getElementById("senha").value;
  auth.createUserWithEmailAndPassword(email, senha)
    .then(() => {
      document.getElementById("mensagem").innerText = "Usuário cadastrado com sucesso!";
    })
    .catch(error => {
      document.getElementById("mensagem").innerText = error.message;
    });
}

function enviarComentario() {
  const comentario = document.getElementById("comentario").value;
  db.collection("comentarios").add({ texto: comentario, timestamp: Date.now() })
    .then(() => {
      document.getElementById("mensagem").innerText = "Comentário enviado!";
    })
    .catch(error => {
      document.getElementById("mensagem").innerText = error.message;
    });
}
